library(testthat)
library(testpackage)

test_check("testpackage")
